import fs from "fs";
import Parser from "rss-parser";
import { GoogleGenAI } from "@google/genai";

const parser = new Parser({ timeout: 20000 });
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
if (!GEMINI_API_KEY) throw new Error("GEMINI_API_KEY is missing");
const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });

const NEWS_FILE = "./news.json";
const MAX_CANDIDATES = 20;
const MAX_NEWS_AGE_HOURS = 48;
const MIN_ARTICLE_WORDS = 700;
const MAX_ARTICLE_WORDS = 1400;

const FEEDS = [
  { name: "Google News", url: "https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en" },
  { name: "Google News India", url: "https://news.google.com/rss/search?q=India&hl=en-IN&gl=IN&ceid=IN:en" },
  { name: "Google News Technology", url: "https://news.google.com/rss/search?q=technology&hl=en-IN&gl=IN&ceid=IN:en" },
  { name: "Google News Sports", url: "https://news.google.com/rss/search?q=sports&hl=en-IN&gl=IN&ceid=IN:en" },
  { name: "Google News Entertainment", url: "https://news.google.com/rss/search?q=entertainment&hl=en-IN&gl=IN&ceid=IN:en" }
];

function loadNews() {
  if (!fs.existsSync(NEWS_FILE)) return [];
  try {
    const data = JSON.parse(fs.readFileSync(NEWS_FILE, "utf8"));
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function saveNews(news) {
  fs.writeFileSync(NEWS_FILE, JSON.stringify(news, null, 2), "utf8");
}

function cleanText(text = "") {
  return String(text)
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function cleanArticle(text = "") {
  return String(text)
    .replace(/\r/g, "")
    .replace(/<[^>]*>/g, "")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function normalizeUrl(url = "") {
  try {
    const u = new URL(url);
    u.hash = "";
    ["utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "gclid", "fbclid"].forEach(p => u.searchParams.delete(p));
    return u.toString().replace(/\/$/, "");
  } catch {
    return url;
  }
}

function hoursOld(date) {
  const t = new Date(date).getTime();
  if (!Number.isFinite(t)) return 9999;
  return Math.max(0, (Date.now() - t) / 3600000);
}

function recencyScore(date) {
  const h = hoursOld(date);
  if (h <= 1) return 100;
  if (h <= 3) return 90;
  if (h <= 6) return 80;
  if (h <= 12) return 70;
  if (h <= 24) return 60;
  if (h <= 48) return 40;
  return 10;
}

function absoluteUrl(value, baseUrl) {
  if (!value) return "";
  try { return new URL(value, baseUrl).href; } catch { return ""; }
}

function extractMeta(html, property, baseUrl) {
  const re = new RegExp(`<meta[^>]+(?:property|name)=["']${property}["'][^>]+content=["']([^"']+)["'][^>]*>`, "i");
  const re2 = new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${property}["'][^>]*>`, "i");
  const m = html.match(re) || html.match(re2);
  return m ? absoluteUrl(m[1].trim(), baseUrl) || cleanText(m[1]) : "";
}

function extractPageText(html) {
  let body = html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ");

  const blocks = [...body.matchAll(/<(?:article|main|p|h1|h2|h3|li)[^>]*>([\s\S]*?)<\/(?:article|main|p|h1|h2|h3|li)>/gi)]
    .map(m => cleanText(m[1]))
    .filter(x => x.length >= 40);

  const unique = [...new Set(blocks)];
  return unique.join("\n\n").slice(0, 30000);
}

async function fetchSourcePage(url) {
  try {
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (compatible; News-Express/1.0; +https://news.google.com/)"
      },
      redirect: "follow",
      signal: AbortSignal.timeout(15000)
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const finalUrl = response.url || url;
    const html = await response.text();
    const image = extractMeta(html, "og:image", finalUrl) || extractMeta(html, "twitter:image", finalUrl);
    const video = extractMeta(html, "og:video", finalUrl) || extractMeta(html, "og:video:url", finalUrl) || extractMeta(html, "twitter:player:stream", finalUrl);
    const description = extractMeta(html, "og:description", finalUrl) || extractMeta(html, "description", finalUrl);
    const text = extractPageText(html);

    return { finalUrl, image, video, description, text };
  } catch (error) {
    console.log(`Source page unavailable: ${error.message}`);
    return { finalUrl: url, image: "", video: "", description: "", text: "" };
  }
}

function getFeedMedia(item) {
  const imageCandidates = [
    item.enclosure?.type?.startsWith?.("image/") ? item.enclosure.url : "",
    item["media:content"]?.url,
    item["media:thumbnail"]?.url,
    item.media?.content?.url,
    item.media?.thumbnail?.url
  ];
  const image = imageCandidates.find(x => x && /^https?:\/\//i.test(x)) || "";

  const html = [item.content, item["content:encoded"], item.summary, item.description].filter(Boolean).join(" ");
  const youtube = html.match(/https?:\/\/(?:www\.)?(?:youtube\.com\/watch\?v=|youtu\.be\/)[^\s"'<>]+/i);
  const directVideo = item.enclosure?.type?.startsWith?.("video/") ? item.enclosure.url : "";
  const video = youtube?.[0]?.replace(/[),.;]+$/, "") || directVideo || "";

  return { image, video };
}

async function fetchFeeds() {
  const articles = [];
  for (const feed of FEEDS) {
    try {
      console.log(`Fetching: ${feed.name}`);
      const result = await parser.parseURL(feed.url);
      for (const item of result.items || []) {
        if (!item.link || !item.title) continue;
        const media = getFeedMedia(item);
        articles.push({
          title: cleanText(item.title),
          url: normalizeUrl(item.link),
          source: feed.name,
          publishedAt: item.isoDate || item.pubDate || new Date().toISOString(),
          description: cleanText(item.contentSnippet || item.content || item.summary || ""),
          image: media.image,
          video: media.video
        });
      }
    } catch (error) {
      console.log(`Feed failed: ${feed.name} - ${error.message}`);
    }
  }
  return articles;
}

function storyKey(title) {
  return title.toLowerCase()
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, " ")
    .split(" ")
    .filter(Boolean)
    .slice(0, 10)
    .join(" ");
}

function groupSimilarStories(articles) {
  const groups = new Map();
  for (const article of articles) {
    const key = storyKey(article.title);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(article);
  }
  return groups;
}

function wordCount(text = "") {
  return cleanArticle(text).split(/\s+/).filter(Boolean).length;
}

async function generateArticle(story, sourcePage) {
  const sourceMaterial = [
    `HEADLINE: ${story.title}`,
    `RSS DESCRIPTION: ${story.description || "Not available"}`,
    `SOURCE PAGE DESCRIPTION: ${sourcePage.description || "Not available"}`,
    `SOURCE PAGE FACTUAL TEXT:\n${sourcePage.text || "Not available"}`
  ].join("\n\n");

  const prompt = `
You are the senior writer for News-Express.

Create a COMPLETE, LONG-FORM NEWS ARTICLE from the verified source material below.
The output must be original writing, not copied from the source.

REQUIREMENTS:
1. Generate ALL of these fields: headline, summary, article, category, tags, keyPoints.
2. The headline must be fresh, clear and accurate.
3. The summary must be 3-4 sentences and explain the main development.
4. The article MUST be long-form: target 1000-1400 words and NEVER intentionally produce a tiny article.
5. Use multiple useful sections. Every section heading MUST start with exactly "## ".
6. Explain the event with context, what happened, important details, reactions or implications ONLY when the supplied material supports them.
7. You may reorganize and synthesize facts, but DO NOT copy source sentences or paragraphs.
8. DO NOT invent facts, statistics, dates, names, quotes, causes, locations or future outcomes.
9. NEVER create a quotation unless the supplied material contains that quotation.
10. If a detail is uncertain or absent, leave it out rather than guessing.
11. Do not mention that you are an AI or that you used source material.
12. Write in polished, neutral newsroom English.
13. tags: 4-8 relevant short tags.
14. keyPoints: 4-6 concise factual bullet-style strings.
15. Return ONLY valid JSON matching the schema.

VERIFIED SOURCE MATERIAL:
${sourceMaterial}
`;

  const schema = {
    type: "object",
    properties: {
      headline: { type: "string" },
      summary: { type: "string" },
      article: { type: "string" },
      category: { type: "string", enum: ["India", "World", "Technology", "Business", "Sports", "Entertainment", "Science", "Other"] },
      tags: { type: "array", items: { type: "string" }, minItems: 4, maxItems: 8 },
      keyPoints: { type: "array", items: { type: "string" }, minItems: 4, maxItems: 6 }
    },
    required: ["headline", "summary", "article", "category", "tags", "keyPoints"]
  };

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-lite",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: schema,
      temperature: 0.7,
      maxOutputTokens: 7000
    }
  });

  const result = JSON.parse(response.text.trim());
  result.article = cleanArticle(result.article);

  if (wordCount(result.article) < MIN_ARTICLE_WORDS) {
    throw new Error(`Gemini returned only ${wordCount(result.article)} words; full article required`);
  }
  if (wordCount(result.article) > MAX_ARTICLE_WORDS + 250) {
    result.article = result.article.split(/\s+/).slice(0, (MAX_ARTICLE_WORDS + 250) * 1).join(" ");
  }

  return result;
}

async function main() {
  console.log("Starting News-Express updater...");

  const oldNews = loadNews();
  const oldUrls = new Set(oldNews.map(x => normalizeUrl(x.url)).filter(Boolean));
  console.log(`Existing archive: ${oldNews.length} articles`);

  const fetched = await fetchFeeds();
  console.log(`Fetched: ${fetched.length} RSS items`);

  const unique = new Map();
  for (const article of fetched) {
    if (!unique.has(article.url)) unique.set(article.url, article);
  }

  const candidates = [...unique.values()]
    .filter(x => hoursOld(x.publishedAt) <= MAX_NEWS_AGE_HOURS)
    .filter(x => !oldUrls.has(x.url))
    .sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt))
    .slice(0, MAX_CANDIDATES);

  console.log(`Candidates for AI generation: ${candidates.length}`);

  const groups = groupSimilarStories(candidates);
  const newArticles = [];

  for (const [, group] of groups) {
    const primary = group[0];
    if (oldUrls.has(primary.url)) continue;

    console.log(`\nProcessing: ${primary.title}`);

    const sourcePage = await fetchSourcePage(primary.url);
    const finalUrl = normalizeUrl(sourcePage.finalUrl || primary.url);

    if (oldUrls.has(finalUrl)) continue;

    // Prefer media from the actual source page; RSS media is the fallback.
    const image = sourcePage.image || primary.image || null;
    const video = sourcePage.video || primary.video || null;

    try {
      console.log("Generating full article with Gemini...");
      const generated = await generateArticle(primary, sourcePage);
      const score = recencyScore(primary.publishedAt) + Math.min(group.length * 10, 40);

      newArticles.push({
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        headline: generated.headline,
        originalTitle: primary.title,
        summary: generated.summary,
        article: generated.article,
        category: generated.category,
        tags: generated.tags,
        keyPoints: generated.keyPoints,
        image,
        video,
        publishedAt: primary.publishedAt,
        addedAt: new Date().toISOString(),
        editorialScore: score,
        url: finalUrl
      });

      console.log(`Generated: ${wordCount(generated.article)} words | image=${Boolean(image)} | video=${Boolean(video)}`);
    } catch (error) {
      console.log(`AI generation failed: ${error.message}`);
    }
  }

  const archive = [...newArticles, ...oldNews];
  archive.sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt));
  saveNews(archive);

  console.log(`\nAdded ${newArticles.length} new articles`);
  console.log(`Permanent archive now contains ${archive.length} articles`);
  console.log("Done.");
}

main().catch(error => {
  console.error("Updater failed:", error);
  process.exit(1);
});
